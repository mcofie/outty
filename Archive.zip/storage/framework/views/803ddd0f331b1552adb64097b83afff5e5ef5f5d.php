<?php $__env->startSection('title',"Event"); ?>

<?php $__env->startSection('main'); ?>
    <div id="event">

    </div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/event.js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/the-outline/resources/views/event.blade.php ENDPATH**/ ?>
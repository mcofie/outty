<?php $__env->startSection('title',"Get started"); ?>

<?php $__env->startSection('main'); ?>
<div id="getstarted">

</div>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/get-started.js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/the-outline/resources/views/get-started.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <title>Hello, world!</title>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <meta name="description" content=""/>
    
    
    <style rel="stylesheet">

    </style>
</head>
<body>
<div class="container">
    <div>
        <div class="card" style="width: 18rem; border:1px solid red;">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the
                    card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
                
                <?php echo e($title); ?>

                <?php echo e($qrcode); ?>

                <?php echo QrCode::format('svg')->generate('Welcome to Makitweb'); ?>

            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/the-outline/resources/views/payment.blade.php ENDPATH**/ ?>
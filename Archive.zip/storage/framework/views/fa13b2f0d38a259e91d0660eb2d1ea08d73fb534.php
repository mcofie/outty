<?php $__env->startSection('title',"Accounts"); ?>

<?php $__env->startSection('main'); ?>
    <div id="account">

    </div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/account.js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/the-outline/resources/views/account.blade.php ENDPATH**/ ?>
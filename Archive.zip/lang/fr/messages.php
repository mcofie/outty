<?php

return [
    'welcome' => 'Welcome to our application!',
    'get_event' => "Détails de l'événement récupérés avec succès",
    'get_slug_lookup_negative' => "Désolé, `:slug` c'est déjà pris",
    'get_slug_lookup_positive' => "Hourra!, `:slug` est disponible"
];

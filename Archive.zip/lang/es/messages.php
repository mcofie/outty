<?php
return [
    'welcome' => 'Welcome to our application!',
    'get_event' => 'Detalles del evento recuperados con éxito',
    'get_slug_lookup_negative' => "¡Perdón!, `:slug` ya está tomado",
    'get_slug_lookup_positive' => "¡Hurra!, `:slug` está disponible"
];

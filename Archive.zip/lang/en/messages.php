<?php
return [
    'welcome' => 'Welcome to our application!',
    'get_event' => 'Event details successfully retrieved',
    'get_slug_lookup_negative' => 'Sorry, `:slug` is already taken',
    'get_slug_lookup_positive' => 'Hooray!, `:slug` is available'
];

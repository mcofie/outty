@extends('main')
@section('title',"Get started")

@section('main')
<div id="getstarted">

</div>
@vite('resources/js/get-started.js')
@endsection

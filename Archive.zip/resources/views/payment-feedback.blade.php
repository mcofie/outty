@extends('main')
@section('title',"Payment feedback")

@section('main')
<div id="paymentFeedback">

</div>
@vite('resources/js/payment-feedback.js')
@endsection

@extends('main')
@section('title',"Landing Page")

@section('main')
    <div id="app">

    </div>
    {{--    @vite(['resources/js/app.js', 'resources/js/app.css'])--}}
    @vite(['resources/js/app.js'])
{{--    <link rel="stylesheet" href="{{ asset('build/assets/app.ba287348.css') }}">--}}

@endsection

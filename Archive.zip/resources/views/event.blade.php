@extends('main')
@section('title',"Event")

@section('main')
    <div id="event">

    </div>
    @vite('resources/js/event.js')
@endsection

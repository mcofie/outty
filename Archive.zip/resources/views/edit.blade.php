@extends('main')
@section('title',"Accounts")

@section('main')
    <div id="edit">

    </div>
    @vite('resources/js/edit.js')
@endsection

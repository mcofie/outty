@extends('main')
@section('title',"Accounts")

@section('main')
    <div id="account">

    </div>
    @vite('resources/js/account.js')
@endsection

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <title>Hello, world!</title>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <meta name="description" content=""/>
    {{--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"--}}
    {{--          integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">--}}
    <style rel="stylesheet">

    </style>
</head>
<body>
<div class="container">
    <div>
        <div class="card" style="width: 18rem; border:1px solid red;">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the
                    card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
                {{--                <img src="../imgs/flower.png"/>--}}
                {{ $title }}
                {{ $qrcode }}
                {!! QrCode::format('svg')->generate('Welcome to Makitweb'); !!}
            </div>
        </div>
    </div>
</div>
</body>
</html>

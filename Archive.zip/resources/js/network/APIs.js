export const APIs = {
    slug: 'events/slug-lookup/',
    createEvent: 'events'
}

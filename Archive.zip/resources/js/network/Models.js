export const CreateEventResponse = {
    data: {
        event: {
            id: 0,
            name: "Strawberry Shows",
            description: "",
            theme_color: "",
            background_color: "",
            text_color: "",
            slug: "",
            primary_typeface: "",
            secondary_typeface: "",
            date: "",
            created: "",
            updated: ""
        }, amount: 0.0, payment_url: "https://p.hbtl.co/MQp4d5"
    }, message: "", status: 200
}

const time = {
    hours: new Date().getHours(),
    minutes: new Date().getMinutes()
};

export const CreateEventLineUp = {
    user: {
        name: "",
        email: "",
        phone_number: ""
    },
    event: {
        name: "",
        description: "",
        slug: "",
        background_color: "#FFFFFF",
        text_color: "#222222",
        primary_typeface: "",
        secondary_typeface: "",
        theme_color: "#CECECE",
        category: '',
        image_id: "",
        date: ""
    },
    lineups: [
        {
            title: "",
            description: "",
            start_time: time,
            end_time: time
        }
    ]
}


export const ComponentEventObject = {
    page: "",
    data: CreateEventLineUp
}



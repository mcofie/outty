<template>
    <div class="container">
        <div class="row justify-content-center text-center mt-5">
            <ul class="list-unstyled opacity-50">
                <li><h6>outty.co 🇬🇭</h6></li>
                <li><small>&copy; All Rights Reserved</small></li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    name: "Footer"
}
</script>

<style scoped>

</style>

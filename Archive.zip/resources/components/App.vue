<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="container">
                    <!-- As a link -->
                    <nav class="navbar bg-body-tertiary py-3 px-2">
                        <div class="container">
                            <div class="d-flex justify-content-between w-100">
                                <h6><a class="navbar-brand" href="#">outty.co</a></h6>

                                <ul class="list-inline">
                                    <li class="list-inline-item"><a href="#">pricing</a></li>
                                    <li class="list-inline-item ml-5"><a href="#">about</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>

                    <div class="hero-section">
                        <div class="row justify-content-center">
                            <div class="col-sm-8 col-md-8">
                                <div class="my-5">
                                    <ul class="list-unstyled text-center">
                                        <li class="mb-4 text-center">
                                            <h1 style="font-size: 4.5rem;">Your Digital Event Lineup in
                                                Minutes</h1>
                                        </li>
                                        <li>
                                            Lorem ipsum dolor sit ametdolor sit amet, Lorem
                                            Lorem ipsum dolor sit amet, Lorem
                                            consectetur adipiscing elit.
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row justify-content-center">
                        <div class="col-md-8 mb-5">
                            <div class="get-started-section p-2 rounded-5">

                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg"><h4>outty.co/</h4></span>
                                    <input type="text" class="form-control" placeholder="your event name"
                                           aria-label="Username"
                                           aria-describedby="basic-addon1">
                                    <button class="btn btn-primary rounded-5" type="button">Create Event</button>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="features-section">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card primary-color">
                                    <div class="card-body text-center text-white">
                                        <ul class="list-unstyled">
                                            <li class="align-content-center my-3">
                                                <div
                                                    class="circle rounded-circle bg-white"></div>
                                            </li>
                                            <li class="mb-3">
                                                <h4>Lorem ipsum dolor sit ametdolor sit amet,</h4>
                                            </li>
                                            <li>
                                                <p>Lorem ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor sit
                                                    ametdolor sit amet,Lorem ipsum dolor sit ametdolor sit amet,Lorem
                                                    ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor sit ametdolor
                                                    sit amet,</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card accentColor">
                                    <div class="card-body text-center justify-content-center">
                                        <ul class="list-unstyled">
                                            <li class="align-content-center my-3">
                                                <div
                                                    class="circle rounded-circle bg-white"></div>
                                            </li>
                                            <li class="mb-3">
                                                <h4>Lorem ipsum dolor sit ametdolor sit amet,</h4>
                                            </li>
                                            <li>
                                                <p>Lorem ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor sit
                                                    ametdolor sit amet,Lorem ipsum dolor sit ametdolor sit amet,Lorem
                                                    ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor sit ametdolor
                                                    sit amet,</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-center my-4">
                            <div class="col-md-12">
                                <div class="card secondary-color">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <ul class="list-unstyled mt-5">
                                                    <li class="mb-3">
                                                        <h4>Lorem ipsum dolor sit ametdolor sit amet,</h4>
                                                    </li>
                                                    <li>
                                                        <p>Lorem ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor
                                                            sit
                                                            ametdolor sit amet,Lorem ipsum dolor sit ametdolor sit
                                                            amet,Lorem
                                                            ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor sit
                                                            ametdolor
                                                            sit amet,</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-md-4">
                                                <div
                                                    class="circle-large rounded-circle bg-white border-1"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="pricing-section">
                        <div class="row justify-content-center">
                            <div class="col-md-6 text-center my-5">
                                <ul class="list-unstyled">
                                    <li>
                                        <h4>PRICING</h4>
                                    </li>
                                    <li>
                                        <h1 class="font-large">
                                            $0.99
                                        </h1>
                                    </li>
                                    <li><p>Create an inclusive event line-up that matter.</p></li>
                                    <li>
                                        <a href="/get-started">
                                            <button class="btn btn-primary rounded-5 btn-lg" type="button">
                                                Create
                                                Event
                                            </button>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="row justify-content-center my-4">
                            <div class="col-md-12">
                                <div class="card grey">
                                    <div class="card-body">
                                        <div class="row justify-content-center">
                                            <div class="col-md-8 text-center">
                                                <ul class="list-unstyled mt-5">
                                                    <li class="mb-3">
                                                        <h4>Lorem ipsum dolor sit ametdolor sit amet,</h4>
                                                    </li>
                                                    <li>
                                                        <p>Lorem ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor
                                                            sit
                                                            ametdolor sit amet,Lorem ipsum dolor sit ametdolor sit
                                                            amet,Lorem
                                                            ipsum dolor sit ametdolor sit amet,Lorem ipsum dolor sit
                                                            ametdolor
                                                            sit amet,</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <footer class="my-4 py-4">
                        <div class="d-flex justify-content-between">
                            <small>&copy; 2023 outty.co</small>
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#">privacy</a></li>
                                <li class="list-inline-item"><a href="#">terms</a></li>
                                <li class="list-inline-item"><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                            </ul>
                        </div>
                    </footer>

                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

import {reactive} from "vue";


</script>

<template>

</template>

<script>
export default {
    name: "EventFront"
}
</script>

<style scoped>

</style>

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrganizerController extends Controller
{
    //

    public function request_token(Request $request)
    {

    }
}
